from .lottery_dcl_ import*
load_historical_data()
calculate_sma()
calculate_rsi()
write_to_csv()